package com.example.bmicalculator;

public class FileExe {
    public static void main(String[] args) {
         Main main = new Main();
    }
}
